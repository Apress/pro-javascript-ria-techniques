// Instantiate the $ library as a singleton right at the end of the file, 
// ready to use on a page which references the $.js file 

$ = new $();